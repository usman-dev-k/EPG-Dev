The migration of this module from 17.0 to 18.0 was financially supported by Camptocamp.
