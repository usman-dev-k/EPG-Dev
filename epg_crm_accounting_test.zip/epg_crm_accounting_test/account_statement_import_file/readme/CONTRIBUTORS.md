- Odoo S.A.
- Alexis de Lattre \<<alexis.delattre@akretion.com>\>
- Tecnativa - Pedro M. Baeza
- Sygel - Manuel Regidor

- Trobz \<<https://www.trobz.com/>\>
  - Do Anh Duy \<<duyda@trobz.com>\>
