- Reconocimiento de partners para otros bancos distintos del Santander,
  CaixaBank, Bankia o Sabadell.
- La moneda se extrae del propio fichero. El mapeo de monedas que viene
  por defecto no es completo. Para tener el valor completo es necesario
  instalar el módulo base_currency_iso_4217.
- Los códigos de operación N43 no se utilizan para asociar una cuenta
  contable genérica, ya que Odoo no lo permite.
