from . import crm_lead
from . import crm_lead_lost
from . import res_partner