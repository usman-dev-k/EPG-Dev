# Copyright 2024 Sygel - Manuel Regidor
# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import test_account_statement_import_file
