The module in NOT compatible with the standard account_asset module.
