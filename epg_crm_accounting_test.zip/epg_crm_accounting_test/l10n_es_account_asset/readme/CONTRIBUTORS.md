- [Tecnativa](https://www.tecnativa.com):
  - Pedro M. Baeza
  - Antonio Espinosa
  - João Marques
- [Sygel](https://www.sygel.es):
  - Valentin Vinagre
  - Manuel Regidor
- [Ingeos](https://ingeos.es/):
  - Sisco Casasempere

