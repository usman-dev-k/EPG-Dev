1.  Vaya a Contabilidad (Facturación) \> Tablero, y escoja "Importar
    extracto" en el cuadro que corresponda con el diario de su banco.
2.  Seleccione el archivo Norma 43 a importar.
3.  Pulse en 'Importar'.
4.  Aparecerá el asistente para conciliación inmediatamente después.
